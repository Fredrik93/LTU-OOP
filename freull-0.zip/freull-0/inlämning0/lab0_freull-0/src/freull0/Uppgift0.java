package freull0;

/**
 * Skriver ut texten hej värld.
 *
 * @author Fredrik Ullman, freull-0
 */

public class Uppgift0
{
    public static void main(String[] args)
    {
        System.out.println("Hej Värld!");
    }
}